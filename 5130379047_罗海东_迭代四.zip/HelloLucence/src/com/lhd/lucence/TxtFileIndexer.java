package com.lhd.lucence;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

/**
 * This class demonstrate the process of creating index with Lucene for text
 * files
 */
public class TxtFileIndexer {

	public static void readToBuffer(StringBuffer buffer, File file) throws IOException {
		InputStream is = new FileInputStream(file);
		String line; // 用来保存每行读取的内容
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		line = reader.readLine(); // 读取第一行
		while (line != null) { // 如果 line 为空说明读完了
			buffer.append(line); // 将读到的内容添加到 buffer 中
			buffer.append("\n"); // 添加换行符
			line = reader.readLine(); // 读取下一行
		}
		reader.close();
		is.close();
	}

	public static void clearIndex(String path) {
		File dir = new File (path);
		if (dir.exists() && dir.isDirectory()) {
			File[] files = dir.listFiles();
			for (int i = files.length-1; i >= 0; i--) {
				files[i].delete();
			}
			dir.delete();
		}
	}
	
	public static void createIndex (String path) {
		File directory = new File (path);
		File[] files = directory.listFiles();
		for (int i = 0; i < files.length; i++) {
			try {
				File file = files[i];
				StringBuffer contentBuffer = new StringBuffer();
				readToBuffer(contentBuffer, file);
				String content = new String(contentBuffer);
				
				Analyzer analyzer = new StandardAnalyzer();
				Directory dir = FSDirectory.open(Paths.get("./index")); // 索引位置
				// Directory directory = new RAMDirectory();

				IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
				IndexWriter iw = new IndexWriter(dir, iwc);
				
				Document doc = new Document();
				doc.add(new TextField("filename", file.getName(), Field.Store.YES));
				doc.add(new TextField("content", content, Field.Store.YES));
				doc.add(new TextField("path", file.getPath(), Field.Store.YES));
				iw.addDocument(doc);
				iw.close();
				dir.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws IOException {
		System.out.println("Starting indexing...");
		clearIndex("./index");
		createIndex("./txt");
		System.out.println ("Index created!");
	}
}