package com.lhd.lucence;

import java.io.IOException;
import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class TxtFileSearcher {
	public static void search(String text) throws IOException, ParseException {
		Analyzer analyzer = new StandardAnalyzer();
		Directory dir = FSDirectory.open(Paths.get("./index"));
		IndexReader reader = DirectoryReader.open(dir);
		
		IndexSearcher is = new IndexSearcher(reader);
		QueryParser parser = new QueryParser("content", analyzer);
		
		Query query = parser.parse(text);
		
		TopDocs topDocs = is.search(query, 1000);
		System.out.println("Find " + topDocs.scoreDocs.length + " document has word '"+ text +"' in total.");
		System.out.println("They are:");
		ScoreDoc[] hits = topDocs.scoreDocs;
		
		for (int i = 0; i < hits.length; i++) {
            Document hitDoc = is.doc(hits[i].doc);
            System.out.println(hitDoc.get("filename"));
            //System.out.println(hitDoc.get("content"));
            //System.out.println(hitDoc.get("path"));
        }
		
		reader.close();
		dir.close();
	}
	
	public static void main(String[] args) throws IOException, ParseException {
		search("happy");
	}
}
